To set up every new terraform configuration and pair it to an AWS account, you'll need some intial set up.  

The `101 getting started` environment shows you all baseline configuration required to do this.  


# To get your terraform up and running
